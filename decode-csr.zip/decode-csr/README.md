# Decode CSR

## Deploy

- Add a certstore directory and create your certificates
- npm start